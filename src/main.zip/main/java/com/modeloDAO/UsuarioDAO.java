/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.modeloDAO;

import com.conexion.conexionDB;
import com.interfaces.CRUD;
import com.modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Kenzy
 */
public class UsuarioDAO implements CRUD{
    conexionDB cn=new conexionDB();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Usuario usr=new Usuario();
    
    @Override
    public List<Usuario> listar() {
        ArrayList<Usuario> list = new ArrayList<>();
        String sql = "SELECT * FROM `usr_ususarios`";
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = cn.getConexionMysql();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            if (!rs.next()) {
                System.out.println("No hay datos en la tabla.");
                return list;
            }

            do {
                Usuario user = new Usuario();
                user.setId(rs.getInt("usr_id"));
                user.setMail(rs.getString("usr_email"));
                user.setContrasenia(rs.getString("usr_contraseña"));
                user.setEsAdmin(rs.getBoolean("usr_es_admin"));
                user.setEsActivo(rs.getBoolean("usr_activo"));
                list.add(user);
            } while (rs.next());

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    
    @Override
    public Usuario list(int id) {
        String sql="select * from usr_ususarios where usr_id="+id;
        try {
            con=cn.getConexionMysql();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){                
                usr.setId(rs.getInt("usr_id"));
                usr.setMail(rs.getString("usr_email"));
                usr.setContrasenia(rs.getString("usr_contraseña"));
                usr.setEsAdmin(rs.getBoolean("usr_es_admin"));
                usr.setEsActivo(rs.getBoolean("usr_activo"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return usr;
    }

    @Override
    public boolean add(Usuario usr) {
       String sql="insert into usr_ususarios(`usr_email`, `usr_contraseña`, `usr_es_admin`, `usr_activo`) "
               + "VALUES ('"+usr.getMail()+
               "','"+usr.getContrasenia()+
               "',"+usr.getEsAdmin()+
               ","+usr.getEsActivo()+
               ")";
        try {
            con=cn.getConexionMysql();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
       return false;
    }

    @Override
    public boolean edit(Usuario usr) {
        String sql = "UPDATE usr_ususarios SET usr_contraseña = ?, usr_es_admin = ?, usr_activo = ? WHERE usr_id = ?";
        try {
            con = cn.getConexionMysql();
            ps = con.prepareStatement(sql);

            ps.setString(1, usr.getContrasenia()); // Establecer la contraseña
            ps.setBoolean(2, usr.getEsAdmin());    // Establecer si es admin
            ps.setBoolean(3, usr.getEsActivo());   // Establecer si está activo
            ps.setInt(4, usr.getId());             // Establecer el ID del usuario

            ps.executeUpdate();
        } catch (SQLException e) {
            // Manejo de excepciones
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean eliminar(int id) {
        String sql="delete from usr_ususarios where usr_id="+id;
        try {
            con=cn.getConexionMysql();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
}
